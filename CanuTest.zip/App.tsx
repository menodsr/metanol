import React, { useRef, useEffect, useState } from 'react';
import Header from './components/Header';
import HeroSection from './components/HeroSection';
import FeaturesSection from './components/FeaturesSection';
import HowItWorksSection from './components/HowItWorksSection';
import PartnershipSection from './components/PartnershipSection';
import TestimonialsSection from './components/TestimonialsSection';
import TrustSealSection from './components/TrustSealSection';
import OrderSection from './components/OrderSection';
import FaqSection from './components/FaqSection';
import Footer from './components/Footer';
import StickyCta from './components/StickyCta';

const AnimatedSection: React.FC<{ children: React.ReactNode; className?: string; }> = ({ children, className }) => {
  const [isVisible, setIsVisible] = useState(false);
  const domRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const observer = new IntersectionObserver(entries => {
      if (entries[0].isIntersecting) {
        setIsVisible(true);
        observer.unobserve(domRef.current!);
      }
    }, { threshold: 0.1 });

    const currentRef = domRef.current;
    if (currentRef) {
      observer.observe(currentRef);
    }
    
    return () => {
      if (currentRef) {
        observer.unobserve(currentRef);
      }
    };
  }, []);

  return (
    <div
      ref={domRef}
      className={`transition-all duration-1000 ease-out ${isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-12'} ${className}`}
    >
      {children}
    </div>
  );
};


const App: React.FC = () => {
  return (
    <div className="bg-background font-sans text-primary antialiased">
      <Header />
      <main>
        <HeroSection />
        <AnimatedSection><FeaturesSection /></AnimatedSection>
        <AnimatedSection><HowItWorksSection /></AnimatedSection>
        <AnimatedSection><PartnershipSection /></AnimatedSection>
        <AnimatedSection><TestimonialsSection /></AnimatedSection>
        <AnimatedSection><TrustSealSection /></AnimatedSection>
        <OrderSection />
        <AnimatedSection><FaqSection /></AnimatedSection>
      </main>
      <Footer />
      <StickyCta />
    </div>
  );
};

export default App;