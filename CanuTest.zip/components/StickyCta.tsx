import React from 'react';

const StickyCta: React.FC = () => {
    return (
        <div className="fixed bottom-0 left-0 right-0 bg-background/90 backdrop-blur-sm p-4 border-t border-gray-800 shadow-[0_-5px_15px_-5px_rgba(0,0,0,0.2)] md:hidden z-40">
            <a 
                href="#order"
                className="w-full block text-center bg-accent hover:bg-accent-hover text-black font-bold py-3 px-6 rounded-md shadow-lg transform active:scale-95 transition-all duration-300"
            >
                Quero o Meu Agora
            </a>
        </div>
    );
};

export default StickyCta;