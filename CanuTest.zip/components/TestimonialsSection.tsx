import React from 'react';

const testimonials = [
  {
    quote: "O SafeSip me dá uma paz de espírito incrível quando saio com amigos. É tão fácil de usar e discreto. Me sinto muito mais segura.",
    name: "Juliana S.",
    location: "São Paulo, SP",
    image: "https://images.unsplash.com/photo-1580489944761-15a19d654956?q=80&w=461&auto=format&fit=crop",
  },
  {
    quote: "Uma ferramenta essencial para quem frequenta bares e festas. Fiquei surpreso com a simplicidade. Todo cidadão consciente deveria ter um.",
    name: "Marcos P.",
    location: "Rio de Janeiro, RJ",
    image: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?q=80&w=387&auto=format&fit=crop",
  },
  {
    quote: "Pedi um para mim e para minha filha que está na faculdade. Saber que ela tem essa proteção não tem preço. Obrigada por essa iniciativa!",
    name: "Ana L.",
    location: "Belo Horizonte, MG",
    image: "https://images.unsplash.com/photo-1494790108377-be9c29b29330?q=80&w=387&auto=format&fit=crop",
  },
];

const StarIcon: React.FC<{ className?: string }> = ({ className }) => (
    <svg className={className} fill="currentColor" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg"><path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z"></path></svg>
);


const TestimonialCard: React.FC<{ quote: string; name: string; location: string; image: string; }> = ({ quote, name, location, image }) => (
    <div className="bg-surface p-8 rounded-lg shadow-lg text-left flex flex-col h-full border border-gray-800">
        <div className="flex text-accent mb-4">
            {[...Array(5)].map((_, i) => <StarIcon key={i} className="w-5 h-5" />)}
        </div>
        <p className="text-secondary italic mb-6 flex-grow">"{quote}"</p>
        <div className="flex items-center mt-auto">
            <img src={image} alt={name} className="w-14 h-14 rounded-full object-cover border-2 border-accent" />
            <div className="ml-4">
                <p className="font-bold text-primary">- {name}</p>
                <p className="text-sm text-secondary">{location}</p>
            </div>
        </div>
    </div>
);

const TestimonialsSection: React.FC = () => {
  return (
    <section id="testimonials" className="py-20 sm:py-28 bg-surface">
      <div className="container mx-auto px-6">
        <h2 className="text-3xl md:text-4xl font-extrabold text-center text-primary mb-16">O que dizem nossos clientes</h2>
        <div className="grid md:grid-cols-3 gap-8">
          {testimonials.map((testimonial, index) => (
            <TestimonialCard key={index} {...testimonial} />
          ))}
        </div>
      </div>
    </section>
  );
};

export default TestimonialsSection;