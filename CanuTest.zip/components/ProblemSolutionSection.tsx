import React from 'react';

const HowItWorksSection: React.FC = () => {
  return (
    <section id="how-it-works" className="py-20 sm:py-28">
      <div className="container mx-auto px-6">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-extrabold mb-3">Como funciona?</h2>
          <p className="max-w-2xl mx-auto text-secondary text-base md:text-lg">
            Simples, rápido e preciso em apenas 4 passos.
          </p>
        </div>
        
        <div className="relative">
          {/* Linha de conexão para desktop */}
          <div className="hidden md:block absolute top-1/2 left-0 w-full h-0.5 bg-surface -translate-y-1/2"></div>
          
          <div className="grid md:grid-cols-4 gap-12 md:gap-8 relative">
            <div className="text-center flex flex-col items-center">
              <div className="relative mb-4 w-16 h-16 flex items-center justify-center bg-surface rounded-full border-2 border-accent text-accent font-bold text-2xl">
                01
              </div>
              <h3 className="font-bold text-lg mb-2">Ligue o aparelho</h3>
            </div>
            <div className="text-center flex flex-col items-center">
              <div className="relative mb-4 w-16 h-16 flex items-center justify-center bg-surface rounded-full border-2 border-accent text-accent font-bold text-2xl">
                02
              </div>
              <h3 className="font-bold text-lg mb-2">Aproxime do copo</h3>
            </div>
            <div className="text-center flex flex-col items-center">
              <div className="relative mb-4 w-16 h-16 flex items-center justify-center bg-surface rounded-full border-2 border-accent text-accent font-bold text-2xl">
                03
              </div>
              <h3 className="font-bold text-lg mb-2">Veja os resultados na hora</h3>
            </div>
            <div className="text-center flex flex-col items-center">
              <div className="relative mb-4 w-16 h-16 flex items-center justify-center bg-surface rounded-full border-2 border-accent text-accent font-bold text-2xl">
                04
              </div>
              <h3 className="font-bold text-lg mb-2">Decida com segurança</h3>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default HowItWorksSection;