import React, { useState } from 'react';

const faqData = [
    {
        question: "O aparelho é recarregável?",
        answer: "Sim, o SafeSip é totalmente recarregável via USB-C, garantindo que ele esteja sempre pronto para te acompanhar. Uma única carga oferece autonomia para dezenas de testes."
    },
    {
        question: "Quanto tempo leva para medir?",
        answer: "O resultado é praticamente instantâneo. Em menos de 5 segundos, o sensor de alta precisão analisa a amostra e exibe o resultado no indicador luminoso, permitindo uma decisão rápida e segura."
    },
    {
        question: "Funciona em qualquer idade?",
        answer: "Sim, o SafeSip foi projetado para ser usado por adultos de qualquer idade. Seu funcionamento é simples e intuitivo, não exigindo nenhum conhecimento técnico."
    },
    {
        question: "Possui garantia?",
        answer: "Com certeza. Oferecemos uma garantia de satisfação de 7 dias. Se por qualquer motivo você não estiver satisfeito, pode devolver o produto. Além disso, o aparelho conta com 1 ano de garantia contra defeitos de fabricação."
    },
];

interface AccordionItemProps {
  question: string;
  answer: string;
  isOpen: boolean;
  onClick: () => void;
}

const AccordionItem: React.FC<AccordionItemProps> = ({ question, answer, isOpen, onClick }) => {
    return (
        <div className="border-b border-gray-800 last:border-b-0">
            <button
                onClick={onClick}
                className="w-full text-left py-5 px-6 flex justify-between items-center focus:outline-none focus-visible:ring-2 focus-visible:ring-accent hover:bg-gray-900 transition-colors"
                aria-expanded={isOpen}
            >
                <span className="text-lg font-medium text-primary">{question}</span>
                <span className={`transform transition-transform duration-300 ${isOpen ? 'rotate-180' : 'rotate-0'}`}>
                    <svg className="w-6 h-6 text-accent" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" /></svg>
                </span>
            </button>
            <div className={`grid transition-all duration-500 ease-in-out ${isOpen ? 'grid-rows-[1fr] opacity-100' : 'grid-rows-[0fr] opacity-0'}`}>
                <div className="overflow-hidden">
                  <div className="p-6 bg-background text-secondary text-base leading-relaxed">
                      {answer}
                  </div>
                </div>
            </div>
        </div>
    );
};

const FaqSection: React.FC = () => {
    const [openIndex, setOpenIndex] = useState<number | null>(0);

    const handleToggle = (index: number) => {
        setOpenIndex(openIndex === index ? null : index);
    };

    return (
        <section id="faq" className="py-20 sm:py-28 bg-background">
            <div className="container mx-auto px-6">
                <h2 className="text-3xl md:text-4xl font-extrabold text-center text-primary mb-16">Perguntas Frequentes</h2>
                <div className="max-w-4xl mx-auto bg-surface rounded-lg shadow-xl overflow-hidden border border-gray-800">
                    {faqData.map((faq, index) => (
                        <AccordionItem
                            key={index}
                            question={faq.question}
                            answer={faq.answer}
                            isOpen={openIndex === index}
                            onClick={() => handleToggle(index)}
                        />
                    ))}
                </div>
            </div>
        </section>
    );
};

export default FaqSection;