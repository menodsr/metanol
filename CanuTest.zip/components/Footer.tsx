import React from 'react';

const Footer: React.FC = () => {
  return (
    <footer className="bg-surface py-8">
      <div className="container mx-auto px-6 text-center text-secondary">
        <p className="text-sm">
          Sua proteção em cada gole. Medidor de Segurança.
        </p>
        <p className="text-xs mt-2">
          &copy; {new Date().getFullYear()} SafeSip. Todos os direitos reservados.
        </p>
      </div>
    </footer>
  );
};

export default Footer;